/***************************************************************
  DISCIPLINA: 203065 - Sistemas Operacionais 

  Shell para execu��o de comandos simples;
     - Esse c�digo roda em Linux;
     - O que fazer para portar para o Xv6?
		- ver c�digo do sh.c

***************************************************************/

#ifdef __XV6  //xv6
	#include "types.h"
	#include "user.h"
	#include "fcntl.h"
	#define NULL 0
#elif __linux
	#include <stdlib.h>
	#include <string.h>
	#include <stdio.h>
#endif

#ifdef __XV6
char * strtok(s, delim)
char *s;
char *delim;
{
     char *spanp;
     int c, sc;
     char *tok;
     static char *last;

     if (s == 0 && (s = last) == 0)
         return (0);

#ifdef DEBUG
    	printf(2, "DEBUG: s = %s(%d)\n", s, strlen(s) );
#endif
 
     /*
 	 * Skip (span) leading delimiters (s += strspn(s, delim), sort of).
 	 */
 cont:
     c = *s++;
     for (spanp = (char *)delim; (sc = *spanp++) != 0;) {
         if (c == sc)
             goto cont;
     }
 
     if (c == 0) {       /* no non-delimiter characters */
         last = 0;
         return (0);
     }
     tok = s - 1;
 
     /*
 	 * Scan token (scan for delimiters: s += strcspn(s, delim), sort of).
 	 * Note that delim must have one NUL; we stop if we see that, too.
 	 */
     for (;;) {
         c = *s++;
         spanp = (char *)delim;
         do {
             if ((sc = *spanp++) == c) {
                 if (c == 0)
                     s = 0;
                 else
                     s[-1] = 0;
                 last = s;
                 return (tok);
             }
         } while (sc != 0);
     }
     /* NOTREACHED */
 }
#endif

int main( void )
{
 char lc[ 81 ];
 char *argv[ 20 ];
 int pid, i;

#ifndef __XV6
	int status;
#endif

 while( 1 ) {
	#ifdef __XV6
		printf(2, "\nPrompt Jaguara> " );  	//Fica esperando pelo comando
		gets(lc, 81);
	#elif __linux
		printf("\nPrompt Jaguara> ");
		gets( lc );
	 					//Captura o comando digitado
	#endif
	if( ! strcmp( lc, "" ) )		//Verifica se nao foi digitado nada
 		continue;
	
	#ifdef __XV6
		lc[strlen(lc)-1] = 0;			//Remove a captura do espa�o em branco
	#endif
	argv[ 0 ] = strtok( lc, " " );		//Quebra a string no delimitador enviado, colocando "0" onde ela quebrou para continuar posteriormente e retorna a primeira palavra
 	if( ! strcmp( argv[ 0 ], "exit" ) )	//Compara se a primeira palavra da string � "exit", se for, encerra a execucao
		#ifdef __XV6
	 		exit();
		#elif __linux
	 		exit(0);
		#endif
	if( ! strcmp( argv[ 0 ], "olar" ) ){
		
		#ifdef __XV6
			printf(2, "\n***Bem vindo ao Prompt Jaguara***\n");
			printf(2, "\nPor favor, vamo se respeitar\n");
			printf(2, "\nDavid Zampier\n\n");
	 		exit();
		#elif __linux
			printf("\n***Bem vindo ao Prompt Jaguara***\n");
			printf("\nPor favor, vamo se respeitar\n");
			printf("\nDavid Zampier\n\n");
			exit(0);
		#endif
	}
	i = 1;					//Variavel de controle para limitar a 19 palavras da cadeia total

	while( i < 20 && (argv[ i ] = strtok( NULL, " " )) )	//Vai armazenando cada palavra da cadeia no argv, separadas pelo delimitador (" ") - equivalente a explode no php, e o null quer dizer para continuar de onde parou
		 ++i;				//Incrementa a variavel de controle
	if( (pid = fork()) == -1 ) {		// Se o fork retornar -1, � porque deu erro e nao criou o filho
		 				// Se o fork retornar 0, a execu��o vai pro processo filho
		#ifdef __XV6
			printf(2, "Erro no fork\n" );  
	 		exit();
		#elif __linux
			printf("Erro no fork\n" );
	 		exit(0);
		#endif		
	}
	if( pid == 0 ){	
		#ifdef __XV6		
			if( exec( argv[ 0 ], argv ) ) {
			 	printf(2, "Erro no execv\n" );
				exit();

		 	}
		#elif __linux
			if( execvp( argv[ 0 ], argv ) ) {
				printf("Erro no execv\n" );
		 		exit(0);
			
			}
		#endif			
		
	}
	#ifdef __XV6
		wait();
	#elif __linux
	 	wait( &status );
	#endif
 }
}
